#include "types.h"
#include "stat.h"
#include "user.h"

void delayOnseSecond(void);

void delayOneSecond(void) {
    // Assuming a rough estimation of loop iterations for one second delay
    long long int iterations = 2147483647; // Adjust this value based on your system's speed

    // Run a loop for approximately one second
    for (long long int i = 0; i < iterations; i++) {
        // This loop will run for approximately one second
        // Perform any desired operations within the loop
    }
}

int main(int argc, char *argv[])
{

    int retime=0, rutime=0, stime=0;
    
    int pid=fork();
   
    if(pid == 0){
        // child
        for(int i=0;i<1000;i++)
        {
        delayOneSecond();
        delayOneSecond();

        }
        
        
        printf(1,"Running some loop for increase running time for the process %d\n",getpid());
        exit();
    }
    else{
        // parent
        wait2(&retime, &rutime, &stime);
         printf(1, "PID: %d, retime: %d, rutime: %d, stime: %d\n", pid, retime, rutime, stime);
    }

    exit();

}