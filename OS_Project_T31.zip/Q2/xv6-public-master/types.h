typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;

struct uproc {
    // Fields as previously described
    uint pid;
    char name[16];
    uint uid;
    uint gid;
    uint ppid;
    uint priority;
    uint sz;
    uint state;

};