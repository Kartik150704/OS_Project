// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"

static void consputc(int);
void showUpElement(void);
int currElemInd = -1;
static int panicked = 0;

static struct
{
  struct spinlock lock;
  int locking;
} cons;
int flag = 0;
#define MAX_INPUT_SIZE 100 // Define maximum input size
#define MAX_Q_SIZE 16      // Maximum size of the circular queue
#define MAX_STRING_LENGTH 100

typedef struct
{
  char buffer[MAX_Q_SIZE][MAX_STRING_LENGTH];
  int front, rear;
  int itemCount;
  int flag;
} CircularQueue;

CircularQueue myQueue;

// Function to initialize the circular queue
void initializeQueue(CircularQueue *queue)
{
  queue->front = -1;
  queue->rear = -1;
  queue->itemCount = 0;
  queue->flag = 0;
}

// Function to check if the queue is empty
int isEmpty(CircularQueue *queue)
{
  return (queue->itemCount == 0);
}

// Function to check if the queue is full
int isFull(CircularQueue *queue)
{
  return (queue->itemCount == MAX_Q_SIZE);
}

// Function to enqueue (insert) a string into the queue
void enqueue(CircularQueue *queue, const char *str)
{

  if (queue->rear == MAX_Q_SIZE - 1)
  {
    queue->flag = 1;
  }
  int len = strlen(str);
  if (len >= MAX_STRING_LENGTH - 1)
  {
    len = MAX_STRING_LENGTH - 1;
  }

  if (isEmpty(queue))
  {
    queue->front = 0;
  }

  queue->rear = (queue->rear + 1) % MAX_Q_SIZE;
  strncpy(queue->buffer[queue->rear], str, len);
  queue->buffer[queue->rear][len] = '\0';
  queue->itemCount++;
}

void displayQueue(CircularQueue *queue)
{

  cprintf("Contents of the queue:\n");

  int count = 0;
  int index = queue->front;
  if (queue->flag == 1)
  {
    for (int i = queue->rear+1; i < MAX_Q_SIZE; i++)
    {
      cprintf("%s\n", queue->buffer[i]);
    }
    for (int i = 0; i <= queue->rear; i++)
    {
      cprintf("%s\n", queue->buffer[i]);
    }
  }
  else
  {
    while (count < queue->itemCount)
    {
      cprintf("%s\n", queue->buffer[index]);
      index = (index + 1) % MAX_Q_SIZE;
      count++;
    }
  }
}

void displayElementFromBack(CircularQueue *queue, int i, char *extractedString)
{
  if (isEmpty(queue) || i < 0 || i >= queue->itemCount)
  {
    return; // Return if the index is invalid, queue is empty, or extractedString is NULL
  }

  int backIndex = (queue->rear - i + MAX_Q_SIZE) % MAX_Q_SIZE;
  char *element = queue->buffer[backIndex];

  // Copy the element to the provided pointer and add '\0' at the end
  int j = 0;
  while (element[j] != '\0' && j < MAX_STRING_LENGTH - 1)
  {
    extractedString[j] = element[j];
    j++;
  }
  extractedString[j] = '\0'; // Null-terminate the string
}

static void
printint(int xx, int base, int sign)
{
  static char digits[] = "0123456789abcdef";
  char buf[16];
  int i;
  uint x;

  if (sign && (sign = xx < 0))
    x = -xx;
  else
    x = xx;

  i = 0;
  do
  {
    buf[i++] = digits[x % base];
  } while ((x /= base) != 0);

  if (sign)
    buf[i++] = '-';

  while (--i >= 0)
    consputc(buf[i]);
}
// PAGEBREAK: 50

// Print to the console. only understands %d, %x, %p, %s.
void cprintf(char *fmt, ...)
{
  int i, c, locking;
  uint *argp;
  char *s;

  locking = cons.locking;
  if (locking)
    acquire(&cons.lock);

  if (fmt == 0)
    panic("null fmt");

  argp = (uint *)(void *)(&fmt + 1);
  for (i = 0; (c = fmt[i] & 0xff) != 0; i++)
  {
    if (c != '%')
    {
      consputc(c);
      continue;
    }
    c = fmt[++i] & 0xff;
    if (c == 0)
      break;
    switch (c)
    {
    case 'd':
      printint(*argp++, 10, 1);
      break;
    case 'x':
    case 'p':
      printint(*argp++, 16, 0);
      break;
    case 's':
      if ((s = (char *)*argp++) == 0)
        s = "(null)";
      for (; *s; s++)
        consputc(*s);
      break;
    case '%':
      consputc('%');
      break;
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
      consputc(c);
      break;
    }
  }

  if (locking)
    release(&cons.lock);
}

void panic(char *s)
{
  int i;
  uint pcs[10];

  cli();
  cons.locking = 0;
  // use lapiccpunum so that we can call panic from mycpu()
  cprintf("lapicid %d: panic: ", lapicid());
  cprintf(s);
  cprintf("\n");
  getcallerpcs(&s, pcs);
  for (i = 0; i < 10; i++)
    cprintf(" %p", pcs[i]);
  panicked = 1; // freeze other CPU
  for (;;)
    ;
}

// PAGEBREAK: 50
#define BACKSPACE 0x100
#define CRTPORT 0x3d4
static ushort *crt = (ushort *)P2V(0xb8000); // CGA memory

static void
cgaputc(int c)
{
  int pos;

  // Cursor position: col + 80*row.
  outb(CRTPORT, 14);
  pos = inb(CRTPORT + 1) << 8;
  outb(CRTPORT, 15);
  pos |= inb(CRTPORT + 1);

  if (c == '\n')
    pos += 80 - pos % 80;
  else if (c == BACKSPACE)
  {
    if (pos > 0)
      --pos;
  }
  else
    crt[pos++] = (c & 0xff) | 0x0700; // black on white

  if (pos < 0 || pos > 25 * 80)
    panic("pos under/overflow");

  if ((pos / 80) >= 24)
  { // Scroll up.
    memmove(crt, crt + 80, sizeof(crt[0]) * 23 * 80);
    pos -= 80;
    memset(crt + pos, 0, sizeof(crt[0]) * (24 * 80 - pos));
  }

  outb(CRTPORT, 14);
  outb(CRTPORT + 1, pos >> 8);
  outb(CRTPORT, 15);
  outb(CRTPORT + 1, pos);
  crt[pos] = ' ' | 0x0700;
}

void consputc(int c)
{
  if (panicked)
  {
    cli();
    for (;;)
      ;
  }

  if (c == BACKSPACE)
  {
    uartputc('\b');
    uartputc(' ');
    uartputc('\b');
  }
  else
    uartputc(c);
  cgaputc(c);
}

#define INPUT_BUF 128
struct
{
  char buf[INPUT_BUF];
  uint r; // Read index
  uint w; // Write index
  uint e; // Edit index
} input;

#define C(x) ((x) - '@') // Control-x
#define MAX_INPUT_SIZE 100
char terminal_input[MAX_INPUT_SIZE];

void saveCommand(char *inputBuf, int end, int start)
{
  char command[MAX_STRING_LENGTH];
  int i = 0;
  int len = end - start - 1;

  // Copy characters from inputBuf to command, considering inputSize
  for (i = 0; i < len; i++)
  {
    command[i] = inputBuf[start + i];
  }
  command[i] = '\0'; // Null-terminate the command

  enqueue(&myQueue, command); // Enqueue the extracted command
}

void consoleintr(int (*getc)(void))
{

  if (flag == 0)
  {
    initializeQueue(&myQueue);
    flag = 1;
  }
  int c, doprocdump = 0;
  acquire(&cons.lock);
  while ((c = getc()) >= 0)
  {
    switch (c)
    {
    case C('P'): // Process listing.
      // procdump() locks cons.lock indirectly; invoke later
      doprocdump = 1;
      break;
    case C('U'): // Kill line.
      while (input.e != input.w &&
             input.buf[(input.e - 1) % INPUT_BUF] != '\n')
      {
        input.e--;
        consputc(BACKSPACE);
      }
      break;
    case '\e':    // ESC key
      c = getc(); // Read the next character after ESC
      if (c == '[')
      {
        c = getc(); // Read the specific key
        if (c == 'A')
        {
          while (input.e != input.w)
          {
            input.e--;
            consputc(BACKSPACE);
          }
          currElemInd=(currElemInd+1)%MAX_Q_SIZE;
          char elem[100];
          if (currElemInd >= myQueue.itemCount)
          {
            currElemInd = 0;
          }
          displayElementFromBack(&myQueue, currElemInd, elem);
          int i = 0;
          while (elem[i] != '\0' && elem[i] != '\n' && input.e < MAX_INPUT_SIZE - 1)
          {
            input.buf[input.r + i] = elem[i];
            input.e++; // Increment the input.e index after adding a character

            consputc(elem[i]);
            i++;
          }

          input.buf[input.e] = '\0';
        }
        else if (c == 'B')
        {
          while (input.e != input.w)
          {
            input.e--;
            consputc(BACKSPACE);
          }
          if (currElemInd <= 0)
          {
          }
          else
          {
            char elem[100];

            currElemInd--;
            displayElementFromBack(&myQueue, currElemInd, elem);
            int i = 0;
            while (elem[i] != '\0' && elem[i] != '\n' && input.e < MAX_INPUT_SIZE - 1)
            {
              input.buf[input.r + i] = elem[i];
              input.e++; // Increment the input.e index after adding a character

              consputc(elem[i]);
              i++;
            }

            input.buf[input.e] = '\0';
          }
          break;
        }
      }
      break;

    case C('H'):
    case '\x7f': // Backspace
      if (input.e != input.w)
      {
        input.e--;
        consputc(BACKSPACE);
      }
      break;

    default:
      if (c != 0 && input.e - input.r < INPUT_BUF)
      {
        c = (c == '\r') ? '\n' : c;
        input.buf[input.e++ % INPUT_BUF] = c;
        consputc(c);

        if (c == '\n' || c == C('D') || input.e == input.r + INPUT_BUF)
        {
          input.w = input.e;
          // Assuming input.buf is a char array (or pointer)
          // Copy characters from input.buf to arr starting from index i
          // Null-terminate the string in arr

          saveCommand(input.buf, input.e, input.r);

          wakeup(&input.r);
        }
      }
      break;
    }
  }
  release(&cons.lock);
  if (doprocdump)
  {
    procdump(); // now call procdump() wo. cons.lock held
  }
}

int consoleread(struct inode *ip, char *dst, int n)
{
  uint target;
  int c;

  iunlock(ip);
  target = n;
  acquire(&cons.lock);
  while (n > 0)
  {
    while (input.r == input.w)
    {
      if (myproc()->killed)
      {
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
    }
    c = input.buf[input.r++ % INPUT_BUF];
    if (c == C('D'))
    { // EOF
      if (n < target)
      {
        // Save ^D for next time, to make sure
        // caller gets a 0-byte result.
        input.r--;
      }
      break;
    }
    *dst++ = c;
    --n;
    if (c == '\n')
      break;
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}

int consolewrite(struct inode *ip, char *buf, int n)
{
  int i;

  iunlock(ip);
  acquire(&cons.lock);
  for (i = 0; i < n; i++)
    consputc(buf[i] & 0xff);
  release(&cons.lock);
  ilock(ip);

  return n;
}

void consoleinit(void)
{
  initlock(&cons.lock, "console");

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
}

void showUpElement(void)
{
}
void tellhistory(void)
{

  displayQueue(&myQueue);
}
